package com.isoftstone.fwk.constant;

import com.isoftstone.fwk.tag.Option;

/**
 * 架构常量类
 * @author jitao
 */
public class FwkConstant {
	
	/**
	 * 封装在Request对象中的异常对象所用的KEY
	 */
	public static String EXCEPTION_REQUEST_KEY = "EXCEPTION_REQUEST_KEY";
	
	/**
	 * 封装在Request对象中的exUniqueId所用的KEY
	 */
	public static String EX_UNIQUE_REQUEST_KEY = "EX_UNIQUE_REQUEST_KEY";
	
	/**
	 * JSON输出FORWARD路径
	 */
	public static String FORWARD_JSON_PATH = "/json";
	
	/**
	 * JSON_PARAM
	 */
	public static String JSON_PARAM = "JSON_PARAM";
	
	/**
	 * respFlg:正常
	 */
	public static String RESP_FLG_NORMAL = "0";
	
	/**
	 * respFlg:警告
	 */
	public static String RESP_FLG_WARN = "1";
	
	/**
	 * respFlg:错误
	 */
	public static String RESP_FLG_ERR = "2";
	
	/**
	 * respFlg:登录过期
	 */
	public static String RESP_FLG_TIMEOUT = "3";
	
	/**
	 * 用户将用户信息储存在session中所用的KEY
	 */
	public static String SESSION_USER_KEY = "SESSION_USER_KEY";
	
	/**
	 * 权限校验失败时使用的FORWARD_KEY
	 */
	public static String FORWARD_KEY_PERMISSION_FAIL = "PermissionFail";
	
	/**
	 * 下拉列表默认选项
	 */
	public static Option DEFAULT_OPTION = new Option("- 请选择 -", "");

}
