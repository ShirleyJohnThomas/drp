package com.isoftstone.fwk.exception;

/**
 * 程序异常。
 * @author jitao
 */
public class AppException extends RuntimeException {
	
	/**
	 * 错误信息
	 */
	private String errMsg;

	/**
	 * AppException
	 */
	public AppException() {
		super();
	}

	/**
	 * AppException
	 * @param message 消息
	 * @param cause 异常cause
	 */
	public AppException(String message, Throwable cause) {
		super(message, cause);
		errMsg = message;
	}

	/**
	 * AppException
	 * @param message 消息
	 */
	public AppException(String message) {
		super(message);
		errMsg = message;
	}

	/**
	 * AppException
	 * @param cause 异常cause
	 */
	public AppException(Throwable cause) {
		super(cause);
		errMsg = cause.getMessage();
	}

	/**
	 * 获得错误信息
	 * @return 错误信息
	 */
	public String getErrMsg() {
		return errMsg;
	}
	
	/**
	 * 重写获得信息方法
	 * @return 错误信息
	 */
	public String getMessage() {
		if (errMsg == null || errMsg.length() == 0) {
			return super.getMessage();
		} else {
			return errMsg;
		}
	}

}
