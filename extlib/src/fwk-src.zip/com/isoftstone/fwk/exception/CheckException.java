package com.isoftstone.fwk.exception;

import java.util.ArrayList;

import com.isoftstone.fwk.helper.BeanHelper;

/**
 * 业务校验异常
 * @author jitao
 */
public class CheckException extends AppException {
	
	/**
	 * 校验消息列表
	 */
	private ArrayList<CheckMessage> checkMessageList = new ArrayList<CheckMessage>();
	
	/**
	 * CheckException
	 */
	public CheckException() {
		super();
	}

	/**
	 * CheckException
	 * @param checkMessageList 校验消息列表
	 * @param cause 异常cause
	 */
	public CheckException(ArrayList<CheckMessage> checkMessageList, Throwable cause) {
		super(BeanHelper.toString(checkMessageList), cause);
		this.checkMessageList = checkMessageList;
	}

	/**
	 * CheckException
	 * @param checkMessageList 校验消息列表
	 */
	public CheckException(ArrayList<CheckMessage> checkMessageList) {
		super(BeanHelper.toString(checkMessageList));
		this.checkMessageList = checkMessageList;
	}
	
	/**
	 * CheckException
	 * @param checkMessage 校验消息
	 * @param cause 异常cause
	 */
	public CheckException(CheckMessage checkMessage, Throwable cause) {
		super(BeanHelper.toString(checkMessage), cause);
		addCheckMessage(checkMessage);
	}

	/**
	 * CheckException
	 * @param checkMessage 校验消息
	 */
	public CheckException(CheckMessage checkMessage) {
		super(BeanHelper.toString(checkMessage));
		addCheckMessage(checkMessage);
	}
	
	/**
	 * 追加校验信息
	 * @param checkMessage 异常信息对象
	 */
	public void addCheckMessage(CheckMessage checkMessage) {
		if (checkMessageList == null) {
			checkMessageList = new ArrayList<CheckMessage>();
		}
		checkMessageList.add(checkMessage);
	}

	/**
	 * 取得校验消息列表
	 * @return 校验消息列表
	 */
	public ArrayList<CheckMessage> getCheckMessageList() {
		return checkMessageList;
	}


}
