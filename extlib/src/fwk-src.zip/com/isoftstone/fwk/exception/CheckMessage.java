package com.isoftstone.fwk.exception;

import com.isoftstone.fwk.helper.BeanHelper;

/**
 * 校验异常信息
 * @author jitao
 */
public class CheckMessage {
	
	/**
	 * 消息内容
	 */
	private String message;
	
	/**
	 * 关联ID
	 */
	private String inputId;
	
	/**
	 * 默认构造方法
	 */
	public CheckMessage() {
	}
	
	/**
	 * 仅适用message构造
	 * @param message 消息内容
	 */
	public CheckMessage(String message) {
		this.message = message;
	}
	
	/**
	 * 使用message和inputId构造
	 * @param message 消息内容
	 * @param inputId 关联ID
	 */
	public CheckMessage(String message, String inputId) {
		this.message = message;
		this.inputId = inputId;
	}

	/**
	 * 取得消息内容
	 * @return 消息内容
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * 设置消息内容
	 * @param message 消息内容
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * 取得关联ID
	 * @return 关联ID
	 */
	public String getInputId() {
		return inputId;
	}

	/**
	 * 设置关联ID
	 * @param inputId 关联ID
	 */
	public void setInputId(String inputId) {
		this.inputId = inputId;
	}
	
	/**
	 * 重写toString
	 */
	public String toString() {
		return BeanHelper.toString(this);
	}

}
