package com.isoftstone.fwk.filter;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.isoftstone.fwk.constant.FwkConstant;
import com.isoftstone.fwk.helper.ActionHelper;
import com.isoftstone.fwk.helper.FwkLogHelper;
import com.isoftstone.fwk.servlet.JsonParam;

/**
 * 登录安全校验过滤器
 * @author jitao
 */
public class CheckLoginFilter implements Filter {
	
	/**
	 * 排除列表
	 */
	private ArrayList<String> excludePathList;
	
	/**
	 * 登录超时时转向的登录页面
	 */
	private String loginPage;
	

	/**
	 * 销毁过滤器
	 */
	public void destroy() {
		// do nothing.
	}

	/**
	 * 执行过滤器
	 * @param req ServletRequest
	 * @param resp ServletResponse
	 * @param chain FilterChain
	 */
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		HttpSession session = request.getSession(false);
		
		String servletPath = request.getServletPath();
		
		Object user = null;
		if (session != null) {
			user = session.getAttribute(FwkConstant.SESSION_USER_KEY);
		}
		
		if (!excludePathList.contains(servletPath) && user == null) {
			FwkLogHelper.LOGGER.info("未登录或登录已超时。");
			if (ActionHelper.isAjaxFlg(request)) {
				// 生成JsonParam对象
				JsonParam jsonParam = new JsonParam(FwkConstant.RESP_FLG_TIMEOUT); // 回应状态：登录过期
				jsonParam.setMessage("登录已超时，请重新登录系统。");
				if (loginPage != null && loginPage.length() > 0) {
					jsonParam.setData(request.getContextPath() + loginPage);
				}
				request.setAttribute(FwkConstant.JSON_PARAM, jsonParam);
				FwkLogHelper.LOGGER.info("转向登录超时JSON输出页面");
				request.getRequestDispatcher(FwkConstant.FORWARD_JSON_PATH).forward(request, response);
			} else {
				if (loginPage != null && loginPage.length() > 0) {
					FwkLogHelper.LOGGER.info("转向登录超时系统登录页面。");
					response.sendRedirect(request.getContextPath() + loginPage);
				} else {
					resp.getWriter().write("Login time out.");
				}
			}
		} else {
			try {
				LoginUserHolder.bindUser(user);
				chain.doFilter(request, response);
			} finally {
				LoginUserHolder.unBindUser();
			}
		}

		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

	public void init(FilterConfig config) throws ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 初始化读取排除列表
		this.excludePathList = new ArrayList<String>();
		String excludePathListStr = config.getInitParameter("excludePathList");
		if (excludePathListStr != null && excludePathListStr.length() > 0) {
			String[] pathArr = excludePathListStr.split(",");
			for (int i = 0; i < pathArr.length; i++) {
				String path = pathArr[i].trim();
				if (path.length() > 0) {
					this.excludePathList.add(path);
				}
			}
			FwkLogHelper.LOGGER.info("CheckLoginFilter设置排除列表为" + this.excludePathList);
		}
		
		// 初始化读取登录超时时转向的登录页面
		String loginPage = config.getInitParameter("loginPage");
		if (loginPage != null && loginPage.length() > 0) {
			this.loginPage = loginPage;
			FwkLogHelper.LOGGER.info("CheckLoginFilter设置超时登录页面为" + this.loginPage);
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

}
