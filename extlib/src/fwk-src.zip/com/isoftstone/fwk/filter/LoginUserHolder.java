package com.isoftstone.fwk.filter;

import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * 已登录的用户
 * @author jitao
 */
public class LoginUserHolder {
	
	/**
	 * 线程保持
	 */
	private static final ThreadLocal<Object> local = new ThreadLocal<Object>();
	
	/**
	 * 绑定User
	 * @param user
	 */
	public static void bindUser(Object user) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		local.set(user);
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 解除绑定User
	 */
	public static void unBindUser() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		local.remove();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 获得User
	 * @return User
	 */
	public static Object getUser() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		Object user = local.get();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return user;
	}
}
