package com.isoftstone.fwk.filter;

import org.hibernate.StatelessSession;

import com.isoftstone.fwk.helper.FwkLogHelper;


/**
 * Session连接线程保持
 * @author jitao
 */
public class SessionHolder {
	
	/**
	 * 储存Session的线程变量
	 */
	private static final ThreadLocal<StatelessSession> local = new ThreadLocal<StatelessSession>();
	
	/**
	 * 储存控制线程Session的事务是否回滚标志的线程变量
	 */
	private static final ThreadLocal<Boolean> localIsRollback = new ThreadLocal<Boolean>();
	
	/**
	 * 绑定session
	 * @param session StatelessSession
	 */
	public static void bindSession(StatelessSession session) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		local.set(session);
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 解除绑定session
	 */
	public static void unBindSession() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		local.remove();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 取得session
	 * @return StatelessSession
	 */
	public static StatelessSession getSession() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		StatelessSession session = local.get();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return session;
	}
	
	/**
	 * 标志是否回滚事务
	 * @param isRollback true:回滚 false:不回滚(提交)
	 */
	public static void markIsRollback(boolean isRollback) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		localIsRollback.set(Boolean.valueOf(isRollback));
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 重设(清空)是否回滚事务标志
	 */
	public static void resetIsRollback() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		localIsRollback.remove();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 判断是否需要回滚事务
	 * @return true:回滚 false:不回滚(提交)
	 */
	public static boolean isRollback() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		boolean isRollback = false;
		Boolean b = localIsRollback.get();
		if (b != null && b.booleanValue()) {
			isRollback = true;
		} else {
			isRollback = false;
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return isRollback;
	}

}
