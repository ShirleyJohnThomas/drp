package com.isoftstone.fwk.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.isoftstone.fwk.constant.FwkConstant;
import com.isoftstone.fwk.helper.ActionHelper;
import com.isoftstone.fwk.helper.FwkLogHelper;
import com.isoftstone.fwk.helper.LostTimeHelper;
import com.isoftstone.fwk.servlet.JsonParam;

/**
 * 设置请求字符集编码的过滤器<br>
 * 此过滤器包含以下功能：<br>
 * ①设置请求字符集编码<br>
 * ②处理请求期间发生的异常
 * @author jitao
 */
public class SetCharacterEncodingFilter implements Filter {
	
	/**
	 * 默认字符集编码
	 */
	private String defaultEncoding;
	
	/**
	 * 异常页面
	 */
	private String exceptionPage;
	
	/**
	 * ServletContext
	 */
	private ServletContext servletContext;
	
	/**
	 * 处理异常
	 * @param e 异常
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 */
	private void handleException(Throwable e, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		// 生成便于查看LOG的异常信息的唯一ID
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String exUniqueId = format.format(new Date()) + "_" + e.hashCode();
		
		FwkLogHelper.LOGGER.error("请求期间出现异常[异常ID:" + exUniqueId + "]。", e);
		
		if (ActionHelper.isAjaxFlg(request) && !response.isCommitted()) {
			
			// 如果请求来自ajax
			// 获得异常信息流
			StringWriter writer = new StringWriter();
			e.printStackTrace(new PrintWriter(writer));
			String stackTrace = writer.toString();
			
			// 封装回应用JSON对象
			JsonParam jsonParam = new JsonParam(FwkConstant.RESP_FLG_ERR);
			jsonParam.setMessage("系统出现异常[异常ID:" + exUniqueId + "]:" + e.getMessage());
			jsonParam.setData(stackTrace);
			request.setAttribute(FwkConstant.JSON_PARAM, jsonParam);
			request.getRequestDispatcher(FwkConstant.FORWARD_JSON_PATH).forward(request, response);
		} else if (this.exceptionPage != null && !response.isCommitted()) {
			
			// 存在异常页面配置，向异常页面转向
			request.setAttribute(FwkConstant.EX_UNIQUE_REQUEST_KEY, exUniqueId);
			request.setAttribute(FwkConstant.EXCEPTION_REQUEST_KEY, e);
			request.getRequestDispatcher(this.exceptionPage).forward(request, response);
		} else {
			
			// 其他情况直接抛出异常
			if (e instanceof IOException) {
				throw (IOException) e;
			} else if (e instanceof ServletException) {
				throw (ServletException) e;
			} else if (e instanceof RuntimeException) {
				throw (RuntimeException) e;
			} else if (e instanceof Error) {
				throw (Error) e;
			} else {
				throw new ServletException(e);
			}
		}
	}

	/**
	 * 销毁过滤器
	 */
	public void destroy() {
		// do nothing.
	}

	/**
	 * 执行过滤器。<br>
	 * 功能描述：<br>
	 * ① 设置请求字符集编码<br>
	 * ② 侦听异常处理
	 * @param req ServletRequest
	 * @param resp ServletResponse
	 * @param chain FilterChain
	 */
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		long sl = LostTimeHelper.start();
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		
		FwkLogHelper.LOGGER.info("IP:" + request.getRemoteAddr() + "开始请求地址(" + request.getRequestURI() + ")。");
		
		// URL参数
		String queryString = request.getQueryString();
		
		// 如果URL的get参数部分包含encoding=xxx的信息，则将encoding信息设置为请求编码
		String encoding = null;
		if (queryString != null && queryString.length() > 0) {
			Pattern p = Pattern.compile("^encoding=[^\\&]+|\\&encoding=[^\\&]+");
			Matcher m = p.matcher(queryString);
			if (m.find()) {
				String param = m.group();
				String[] strArr = param.split("\\=");
				if (strArr.length > 1) {
					encoding = strArr[1];
				}
			}
		}
		
		// 如果URL的get参数部分包含ajaxFlg=xxx的信息，来表示请求是否来自ajax
		String ajaxFlg = null;
		if (queryString != null && queryString.length() > 0) {
			Pattern p = Pattern.compile("^ajaxFlg=[^\\&]+|\\&ajaxFlg=[^\\&]+");
			Matcher m = p.matcher(queryString);
			if (m.find()) {
				String param = m.group();
				String[] strArr = param.split("\\=");
				if (strArr.length > 1) {
					ajaxFlg = strArr[1];
				}
			}
		}
		
		if (ajaxFlg != null && ajaxFlg.equals("1")) {
			ActionHelper.markAjaxFlg(request);
		}
		
		// 设置请求编码
		if (encoding != null) {
			try {
				request.setCharacterEncoding(encoding);
				FwkLogHelper.LOGGER.info("设置请求编码为 '" + encoding + "'。");
			} catch (UnsupportedEncodingException e) {
				// 编码不支持，不设置请求编码
				FwkLogHelper.LOGGER.warn("系统不支持编码'" + encoding + "'，请求编码将不被设置。");
			}
		} else if (this.defaultEncoding != null) {
			request.setCharacterEncoding(this.defaultEncoding);
			FwkLogHelper.LOGGER.info("设置请求编码为 '" + this.defaultEncoding + "'。");
		}
		
		try {
			ActionHelper.bindApplicationContext(WebApplicationContextUtils.getWebApplicationContext(this.servletContext));
			chain.doFilter(req, resp);
		} catch (Throwable e) {
			handleException(e, request, response);
		} finally {
			ActionHelper.unBindApplicationContext();
		}
		
		FwkLogHelper.LOGGER.info("IP:" + request.getRemoteAddr() + "请求地址完成(" + request.getRequestURI() + ")，耗时" + LostTimeHelper.end(sl) + "(s)。");
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

	/**
	 * 初始化过滤器。
	 * @param config FilterConfig
	 */
	public void init(FilterConfig config) throws ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 设置默认请求字符集编码
		String encoding = config.getInitParameter("defaultEncoding");
		if (encoding != null && encoding.length() > 0) {
			this.defaultEncoding = encoding;
			FwkLogHelper.LOGGER.info("设置默认请求编码为 '" + encoding + "'。");
		}
		
		// 设置异常页面
		String exPage = config.getInitParameter("exceptionPage");
		if (exPage != null && exPage.length() > 0) {
			this.exceptionPage = exPage;
			FwkLogHelper.LOGGER.info("设置公共异常页面为 '" + exPage + "'。");
		}
		
		this.servletContext = config.getServletContext();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
}
