package com.isoftstone.fwk.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * JDBC的Session管理辅助filter<br>
 * ①如果设置了enableHolder为true，则在当前线程内开启一个JDBC连接<br>
 * ②如果设置了enableTransactionCtrl为true，则在整个请求期间自动控制一次事务<br>
 * ※如果开启了enableTransactionCtrl，则enableHolder也必须开启，否则在初始化时将抛出异常
 * @author jitao
 */
public class TransactionManagerFilter implements Filter {
	
	/**
	 * 是否激活Session线程保持
	 */
	private boolean enableHolder = false;
	
	/**
	 * 是否激活事务控制
	 */
	private boolean enableTransactionCtrl = false;
	
	/**
	 * SessionFactory
	 */
	private SessionFactory sessionFactory;

	/**
	 * 销毁过滤器
	 */
	public void destroy() {
		// do nothing
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		
		try {
			StatelessSession session = null;
			
			if (enableHolder) {
				
				// 取得StatelessSession并绑定到线程变量中
				session = sessionFactory.openStatelessSession();
				FwkLogHelper.LOGGER.info("Hibernate session 已创建。");
				SessionHolder.bindSession(session);
				FwkLogHelper.LOGGER.info("Hibernate session 已绑定线程。");
			}
			
			try {
				
				// 开启事务
				if (enableTransactionCtrl) {
					session.beginTransaction();
					FwkLogHelper.LOGGER.info("Hibernate session 事务已启动。");
					
					SessionHolder.markIsRollback(false);
					FwkLogHelper.LOGGER.info("已默认设置事务回滚标志为false。");
				}
				
				// 执行
				chain.doFilter(request, response);
				
				// 提交事务
				if (enableTransactionCtrl) {
					Transaction trans = session.getTransaction();
					if (trans != null && trans.isActive()) {
						
						// 如果系统需要回滚事务，则进行事务回滚，否则进行事务提交处理。
						if (SessionHolder.isRollback()) {
							trans.rollback();
							FwkLogHelper.LOGGER.info("Hibernate session 事务已回滚。");
						} else {
							trans.commit();
							FwkLogHelper.LOGGER.info("Hibernate session 事务已提交。");
						}
					}
				}
			} catch (Throwable e) {
				
				// 为保证程序完整性，这里无论出现Exception还是Error都需要回滚事务
				if (enableTransactionCtrl) {
					Transaction trans = session.getTransaction();
					if (trans != null && trans.isActive()) {
						trans.rollback();
						FwkLogHelper.LOGGER.info("Hibernate session 事务已回滚。");
					}
				}
				throw e;
			} finally {
				
				// 在线程变量中解除绑定Session
				if (enableHolder) {
					session.close();
					FwkLogHelper.LOGGER.info("Hibernate session 已关闭。");
					SessionHolder.unBindSession();
					FwkLogHelper.LOGGER.info("Hibernate session 已解除绑定。");
				}
				
				// 在线程变量中重置事务回滚标志
				if (enableTransactionCtrl) {
					
					SessionHolder.resetIsRollback();
					FwkLogHelper.LOGGER.info("置事务回滚标志已重置。");
				}
			}
			
		} catch (IOException ioe) {
			throw ioe;
		} catch (ServletException se) {
			throw se;
		} catch (RuntimeException re) {
			throw re;
		} catch (Error err) {
			throw err;
		} catch (Throwable e) {
			throw new ServletException(e);
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig config) throws ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		String enableHolderStr = config.getInitParameter("enableHolder");
		String enableTransactionCtrlStr = config.getInitParameter("enableTransactionCtrl");
		enableHolder = Boolean.parseBoolean(enableHolderStr);
		enableTransactionCtrl = Boolean.parseBoolean(enableTransactionCtrlStr);
		
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(config.getServletContext());
		sessionFactory = (SessionFactory) context.getBean("sessionFactory");
		
		if (enableTransactionCtrl && !enableHolder) {
			ServletException appEx = new ServletException("激活了事务控制同时还需要激活Session的保持。");
			FwkLogHelper.LOGGER.error("ConnectionManagerFilter初始化失败", appEx);
			throw appEx;
		}
		FwkLogHelper.LOGGER.info("enableHolder=[" + enableHolder + "], enableTransactionCtrl=[" + enableTransactionCtrl + "]");
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

}
