package com.isoftstone.fwk.gson;

import java.lang.reflect.Type;
import java.util.Date;

import com.google.gson.CustomerHolder;
import com.google.gson.FieldAttributes;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.isoftstone.fwk.annotation.DateField;
import com.isoftstone.fwk.helper.DataHelper;

/**
 * Gson的Date类型TypeAdapter
 * @author jitao
 */
public class GsonDateTypeAdapter implements JsonSerializer<Date> {
	
	/**
	 * 默认格式
	 */
	private static String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";

	/**
	 * 默认构造器
	 */
	public GsonDateTypeAdapter() {
	}

	/**
	 * 序列化操作
	 * @param src Date对象
	 * @param typeOfSrc 类型
	 * @param context JsonSerializationContext对象
	 * @return JsonElement对象
	 */
	public JsonElement serialize(Date src, Type typeOfSrc,
			JsonSerializationContext context) {
		if (src == null) {
			return null;
		}
		String pattern = DEFAULT_PATTERN;
		FieldAttributes fieldAttrs = CustomerHolder.getFieldAttributes();
		if (fieldAttrs != null) {
			DateField dateAnno = fieldAttrs.getAnnotation(DateField.class);
			if (dateAnno != null) {
				pattern = dateAnno.value();
			}
		}
		String dateFormatAsString = DataHelper.fmtDate(src, pattern);
		return new JsonPrimitive(dateFormatAsString);
	}
}
