package com.isoftstone.fwk.gson;

import java.lang.reflect.Type;
import java.math.BigDecimal;

import com.google.gson.CustomerHolder;
import com.google.gson.FieldAttributes;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.isoftstone.fwk.helper.DataHelper;

/**
 * Gson的Number类型TypeAdapter
 * @author jitao
 */
public class GsonNumberTypeAdapter implements JsonSerializer<Number> {

	/**
	 * 序列化操作
	 * @param src Number对象
	 * @param typeOfSrc 类型
	 * @param context JsonSerializationContext对象
	 * @return JsonElement对象
	 */
	public JsonElement serialize(Number src, Type typeOfSrc,
			JsonSerializationContext context) {
		if (src == null) {
			return null;
		}
		String pattern = null;
		FieldAttributes fieldAttrs = CustomerHolder.getFieldAttributes();
		if (fieldAttrs != null) {
			com.isoftstone.fwk.annotation.DecimalField anno =
				fieldAttrs.getAnnotation(com.isoftstone.fwk.annotation.DecimalField.class);
			if (anno != null) {
				pattern = anno.value();
			}
		}
		return new JsonPrimitive(DataHelper.fmtNumber(src, pattern));
	}


}
