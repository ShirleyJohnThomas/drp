package com.isoftstone.fwk.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;

/**
 * Action帮助类
 * @author jitao
 */
public class ActionHelper {
	
	/**
	 * Spring ApplicationContext保持
	 */
	private static final ThreadLocal<ApplicationContext> contextLocal = new ThreadLocal<ApplicationContext>();
	
	/**
	 * 信息KEY
	 */
	private static final String RESPONSE_MESSAGE_REQUEST_KEY = "RESPONSE_MESSAGE_REQUEST_KEY";
	
	/**
	 * 数据KEY
	 */
	private static final String RESPONSE_DATA_REQUEST_KEY = "RESPONSE_DATA_REQUEST_KEY";
	
	/**
	 * 自定义数据KEY
	 */
	private static final String RESPONSE_CUS_DATA_REQUEST_KEY = "RESPONSE_CUS_DATA_REQUEST_KEY";
	
	/**
	 * 封装在Request对象中的记录请求是否来自ajax的标志所用的KEY
	 */
	private static final String AJAX_FLG_REQUEST_KEY = "AJAX_FLG_REQUEST_KEY";
	
	/**
	 * 追加回应消息
	 * @param request HttpServletRequest
	 * @param message 消息正文
	 */
	public static void addResponseMessage(HttpServletRequest request, String message) {
		List<String> messageList = getResponseMessageList(request);
		if (messageList == null) {
			messageList = new ArrayList<String>();
			setResponseMessageList(request, messageList);
		}
		messageList.add(message);
	}
	
	/**
	 * 设置回应消息列表
	 * @param request HttpServletRequest
	 * @param message 消息正文列表
	 */
	public static void setResponseMessageList(HttpServletRequest request, List<String> messageList) {
		request.setAttribute(RESPONSE_MESSAGE_REQUEST_KEY, messageList);
	}
	
	/**
	 * 取得回应消息列表
	 * @param request HttpServletRequest
	 * @return 消息正文列表
	 */
	public static List<String> getResponseMessageList(HttpServletRequest request) {
		return (List<String>) request.getAttribute(RESPONSE_MESSAGE_REQUEST_KEY);
	}
	
	/**
	 * 设置回应自定义数据 
	 * @param request HttpServletRequest
	 * @param cusData 自定义数据
	 */
	public static void setResponseCusData(HttpServletRequest request, Object cusData) {
		request.setAttribute(RESPONSE_CUS_DATA_REQUEST_KEY, cusData);
	}
	
	/**
	 * 取得回应自定义数据
	 * @param request HttpServletRequest
	 * @return 自定义数据
	 */
	public static Object getResponseCusData(HttpServletRequest request) {
		return request.getAttribute(RESPONSE_CUS_DATA_REQUEST_KEY);
	}
	
	/**
	 * 设置回应数据 
	 * @param request HttpServletRequest
	 * @param cusData 数据
	 */
	public static void setResponseData(HttpServletRequest request, Object data) {
		request.setAttribute(RESPONSE_DATA_REQUEST_KEY, data);
	}
	
	/**
	 * 取得回应数据
	 * @param request HttpServletRequest
	 * @return 数据
	 */
	public static Object getResponseData(HttpServletRequest request) {
		return request.getAttribute(RESPONSE_DATA_REQUEST_KEY);
	}
	
	/**
	 * 标记AJAX标志
	 * @param request HttpServletRequest
	 */
	public static void markAjaxFlg(HttpServletRequest request) {
		request.setAttribute(AJAX_FLG_REQUEST_KEY, "1");
	}
	
	/**
	 * 是否AJAX标志
	 * @param request HttpServletRequest
	 * @return AJAX标志:true;false
	 */
	public static boolean isAjaxFlg(HttpServletRequest request) {
		return request.getAttribute(AJAX_FLG_REQUEST_KEY) == null ? false : true;
	}
	
	/**
	 * 绑定ApplicationContext
	 * @param context ApplicationContext
	 */
	public static void bindApplicationContext(ApplicationContext context) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		contextLocal.set(context);
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 解除绑定ApplicationContext
	 */
	public static void unBindApplicationContext() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		contextLocal.remove();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 获得系统配置消息
	 * @param msgId 消息ID
	 * @param args 参数值
	 * @return 系统消息，找不到时返回 "??? msgId ???"
	 */
	public static String getMessage(String msgId, String... args) {
		String msg = contextLocal.get().getMessage(msgId, args, "$$none$$", null);
		if (msg.equals("$$none$$")) {
			msg = "??? " + msgId + " ???";
		} else {
			msg = "【" + msgId + "】" + msg;
		}
		return msg;
	}
	
	/**
	 * 取得ApplicationContext
	 * @return ApplicationContext
	 */
	/*public static ApplicationContext getApplicationContext() {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		ApplicationContext context = contextLocal.get();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return context;
	}*/
	
}
