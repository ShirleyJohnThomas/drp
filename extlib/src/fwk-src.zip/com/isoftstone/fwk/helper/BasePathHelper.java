package com.isoftstone.fwk.helper;

import java.io.File;
import java.io.IOException;

import com.isoftstone.fwk.exception.AppException;

/**
 * 基本路径帮助
 * @author jitao
 */
public class BasePathHelper {
	
	/**
	 * 基本路径
	 */
	private static String basePath;

	/**
	 * 取得基本路径
	 * @return 基本路径
	 */
	public static String getBasePath() {
		return basePath;
	}
	
	/**
	 * 获取Web环境中的绝对路径
	 * @param path 相对路径
	 * @return 绝对路径
	 */
	public static String getRealPath(String path) throws IOException {
		if (basePath == null) {
			throw new AppException("没有设置basePath！");
		}
		File file = new File(basePath, path);
		return file.getCanonicalPath();
		
	}

	/**
	 * 设置基本路径<br>
	 * Note:基本路径只能被设置一次。
	 * @param basePath 基本路径
	 */
	public static void setBasePath(String basePath) {
		if (BasePathHelper.basePath == null) {
			BasePathHelper.basePath = basePath;
		}
	}
}
