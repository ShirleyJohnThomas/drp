package com.isoftstone.fwk.helper;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * 主要用于简便使用类反射机制。
 * @author jitao
 */
public class BeanHelper {
	
	
	/**
	 * 获得指定class类中声明的字段(包含父类中的字段)
	 * @param cls Class类
	 * @return 字段数组
	 */
	public static List<Field> getAllFields(Class cls) {
		ArrayList<Field> fieldList = new ArrayList<Field>();
		while (cls != null) {
			Field[] fields = cls.getDeclaredFields();
			Collections.addAll(fieldList, fields);
			cls = cls.getSuperclass();
		}
		return fieldList;
	}
	
	/**
	 * 获得指定对象所表示的类中声明的字段(包含父类中的字段)
	 * @param obj 指定对象
	 * @return 字段数组
	 */
	public static List<Field> getAllFields(Object obj) {
		return getAllFields(obj.getClass());
	}
	
	/**
	 * 获得指定class类中指定声明的字段(通过继承级别由子类像父类依次寻找)
	 * @param cls Class类
	 * @param name 指定字段名称
	 * @return 指定字段，找不到时返回null
	 */
	public static Field getDeclaredField(Class cls, String name) {
		while (cls != null) {
			try {
				return cls.getDeclaredField(name);
			} catch (NoSuchFieldException e) {
				// do nothing.
			}
			cls = cls.getSuperclass();
		}
		return null;
	}
	
	/**
	 * 获得指定对象所表示的类中指定声明的字段(通过继承级别由子类像父类依次寻找)
	 * @param obj 指定对象
	 * @param name 指定字段名称
	 * @return 指定字段，找不到时返回null
	 */
	public static Field getDeclaredField(Object obj, String name) {
		return getDeclaredField(obj.getClass(), name);
	}
	
	/**
	 * 对象输出字符串
	 * @param bean 实例
	 * @return 字符串
	 */
	public static String toString(Object bean) {
		return ToStringBuilder.reflectionToString(bean, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
