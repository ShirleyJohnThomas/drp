package com.isoftstone.fwk.helper;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

import com.isoftstone.fwk.exception.AppException;

/**
 * 数据相关帮助类
 * @author jitao
 */
public class DataHelper {
	
	/**
	 * 格式化日期默认格式
	 */
	public static String DATE_DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	/**
	 * String转化为日期尝试使用的pattern
	 */
	public static String[] DATE_PATTERNS = new String[]{"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM"};
	
	/**
	 * 根据指定的pattern转换Date到字符串。<br>
	 * 若date未指定，将返回空字符串''<br>
	 * 若pattern未指定，将默认使用'yyyy-MM-dd HH:mm:ss.SSS'<br>
	 * @param date 日期
	 * @param pattern 模式
	 * @return 格式化后的字符串
	 */
	public static String fmtDate(Date date, String pattern) {
		if (date == null) {
			return "";
		} else {
			if (pattern == null || pattern.length() == 0) {
				pattern = DATE_DEFAULT_PATTERN;
			}
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			return format.format(date);
		}
	}
	
	/**
	 * 转换字符串到Date。<br>
	 * 若datestr未指定，将返回null<br>
	 * @param datestr 日期字符串
	 * @return 日期对象
	 */
	public static Date parseDate(String datestr) {
		if (datestr == null || datestr.length() == 0) {
			return null;
		} else {
			try {
				return DateUtils.parseDate(datestr, DATE_PATTERNS);
			} catch (ParseException e) {
				throw new AppException("转换日期字符串[" + datestr + "]错误！", e);
			}
		}
	}
	
	/**
	 * 日期转换成只有日期的字符串(yyyy-MM-dd)
	 * @param date 日期对象
	 * @return 日期字符串
	 */
	public static String toDateOnlyString(Date date) {
		return fmtDate(date, "yyyy-MM-dd");
	}
	
	/**
	 * 日期转换成包含日期、时间的字符串(yyyy-MM-dd HH:mm:ss)
	 * @param date 日期对象
	 * @return 日期字符串
	 */
	public static String toDatetimeString(Date date) {
		return fmtDate(date, "yyyy-MM-dd HH:mm:ss");
	}
	
	/**
	 * 将一个数字对象按照指定pattern格式化
	 * @param num 数字对象
	 * @param pattern 格式
	 * @return 格式化后字符串
	 */
	public static String fmtNumber(Number num, String pattern) {
		if (num == null) {
			return "";
		} else {
			BigDecimal number = null;
			if (num instanceof BigDecimal) {
				number = (BigDecimal) num;
			} else {
				number = BigDecimal.valueOf(num.doubleValue());
			}
			if (pattern == null || pattern.length() == 0) {
				return number.toPlainString().replaceAll("\\.0+$", "");
			} else {
				int scale = 0;
				String[] splitArr = pattern.split("\\.");
				if (splitArr.length > 1) {
					scale = splitArr[splitArr.length - 1].length();
				}
				number = number.setScale(scale, BigDecimal.ROUND_HALF_UP);
				return new DecimalFormat(pattern).format(number);
			}
		}
	}
}
