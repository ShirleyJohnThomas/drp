package com.isoftstone.fwk.helper;

import org.apache.log4j.Logger;

import com.isoftstone.fwk.helper.LostTimeHelper;

/**
 * Log帮助
 * @author jitao
 */
public class FwkLogHelper {
	
	/**
	 * 方法开始信息
	 */
	private static String METHOD_START_MSG = "<<Method is start.>>";
	
	/**
	 * 方法结束信息
	 */
	private static String METHOD_END_MSG = "<<Method is end.>>";
	
	/**
	 * Logger对象
	 */
	public static Logger LOGGER = Logger.getLogger("com.isoftstone.fwk");
	
	/**
	 * 获得方法开始信息
	 * @return 方法开始信息
	 */
	public static String getMethodStartMessage() {
		return METHOD_START_MSG;
	}
	
	/**
	 * 获得方法结束信息
	 * @return 方法结束信息
	 */
	public static String getMethodEndMessage() {
		return METHOD_END_MSG;
	}
	
	/**
	 * 获得方法结束信息，并输出与startTime比较的耗时
	 * @param startTime 计算耗时用的开始时间
	 * @return 带有耗时信息的方法结束信息
	 */
	public static String getMethodEndMessage(long startTime) {
		if (LOGGER.isDebugEnabled()) {
			double differ = LostTimeHelper.end(startTime);
			return METHOD_END_MSG + "Lost time " + differ + "(s)";
		} else {
			return getMethodEndMessage();
		}
	}
}
