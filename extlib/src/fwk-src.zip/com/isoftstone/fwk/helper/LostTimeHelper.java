package com.isoftstone.fwk.helper;

import java.util.Date;

/**
 * 用户性能测试的耗时帮助
 * @author jitao
 */
public class LostTimeHelper {
	
	/**
	 * 开始
	 * @return 开始时间(long型)
	 */
	public static long start() {
		return (new Date().getTime());
	}
	
	/**
	 * 利用与开始时间之间的差距计算耗时时间
	 * @param startTime 开始时间
	 * @return 耗时(单位：秒)
	 */
	public static double end(long startTime) {
		long endTime = new Date().getTime();
		double differ = (endTime - startTime) / 1000D;
		return differ;
	}
}
