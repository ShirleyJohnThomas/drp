package com.isoftstone.fwk.listener;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.beanutils.converters.CalendarConverter;
import org.apache.commons.beanutils.converters.ConverterFacade;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.DoubleConverter;
import org.apache.commons.beanutils.converters.FloatConverter;
import org.apache.commons.beanutils.converters.IntegerConverter;
import org.apache.commons.beanutils.converters.LongConverter;

import com.isoftstone.fwk.helper.BasePathHelper;
import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * 初始化Listener
 * @author jitao
 */
public class FwkInitListener implements ServletContextListener {
	
	/**
	 * 注册BeanUtils组件中的相关转换器
	 */
	private void registerBeanUtilsConverters() {
		final String[] DATE_PATTERNS = new String[]{"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM"};
		
		// 注册java.util.Date转换器
		DateConverter dc = new DateConverter(null);
		dc.setPatterns(DATE_PATTERNS);
		ConvertUtils.register(new ConverterFacade(dc), Date.class);
		
		// 注册java.util.Calendar转换器
		CalendarConverter cc = new CalendarConverter(null);
		cc.setPatterns(DATE_PATTERNS);
		ConvertUtils.register(new ConverterFacade(cc), Calendar.class);
		
		// 注册java.lang.Double转换器
		DoubleConverter doublec = new DoubleConverter(null);
		ConvertUtils.register(new ConverterFacade(doublec), Double.class);
		
		// 注册java.lang.Float转换器
		FloatConverter floatc = new FloatConverter(null);
		ConvertUtils.register(new ConverterFacade(floatc), Float.class);
		
		// 注册java.lang.Long转换器
		LongConverter longc = new LongConverter(null);
		ConvertUtils.register(new ConverterFacade(longc), Long.class);
		
		// 注册java.lang.Integer转换器
		IntegerConverter integerc = new IntegerConverter(null);
		ConvertUtils.register(new ConverterFacade(integerc), Integer.class);
		
		// 注册java.math.BigDecimal转换器
		BigDecimalConverter bdc = new BigDecimalConverter(null);
		ConvertUtils.register(new ConverterFacade(bdc), BigDecimal.class);
	}

	/**
	 * 销毁侦听器
	 * @param event ServletContextEvent
	 */
	public void contextDestroyed(ServletContextEvent event) {
		// do nothing.
	}

	/**
	 * 初始化侦听器<br>
	 * ① 记录BasePath
	 * @param event ServletContextEvent
	 */
	public void contextInitialized(ServletContextEvent event) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		ServletContext servletContext = event.getServletContext();
		
		// 设置应用的基路径
		BasePathHelper.setBasePath(servletContext.getRealPath("/"));
		
		// 注册BeanUtils组件中的相关转换器(用于struts的ActionForm参数赋值)
		registerBeanUtilsConverters();
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

}
