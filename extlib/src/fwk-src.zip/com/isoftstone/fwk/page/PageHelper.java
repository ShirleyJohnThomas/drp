package com.isoftstone.fwk.page;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.StatelessSession;

import com.isoftstone.fwk.exception.AppException;
import com.isoftstone.fwk.filter.SessionHolder;
import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * 分页帮助类
 * @author jitao
 */
public class PageHelper {
	
	/**
	 * 使用SQL查询进行分页查询
	 * @param pageInfo 分页信息
	 * @param querySql 查询SQL
	 * @param parameterMap 参数MAP
	 * @return 查询结果
	 */
	public static List calcSqlPageInfo(PageInfo pageInfo, String querySql, Map parameterMap) {
		return calcPageInfo(pageInfo, querySql, null, parameterMap);
	}
	
	/**
	 * 使用HQL查询进行分页查询
	 * @param pageInfo 分页信息
	 * @param queryHql 查询HQL
	 * @param parameterMap 参数MAP
	 * @return 查询结果
	 */
	public static List calcHqlPageInfo(PageInfo pageInfo, String queryHql, Map parameterMap) {
		return calcPageInfo(pageInfo, null, queryHql, parameterMap);
	}
	
	
	/**
	 * 分页查询
	 * @param pageInfo 分页信息
	 * @param querySql 查询SQL
	 * @param queryHql 查询HQL
	 * @param parameterMap 参数MAP
	 * @return 查询结果
	 */
	private static List calcPageInfo(PageInfo pageInfo, String querySql, String queryHql, Map parameterMap) {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 取得Session
		StatelessSession session = SessionHolder.getSession();
		
		// 总记录数
		int rowCount = 0;
		
		if (querySql != null) {
			
			// 使用SQL进行总记录数查询
			String countsql = querySql;
			int index = querySql.toLowerCase().indexOf("from");
			if (index == -1) {
				throw new AppException("分页处理：querySql必须包含from关键字");
			} else if (index > 0) {
				countsql = countsql.substring(index);
			}
			countsql = "select count(*) as count " + countsql;
			SQLQuery sqlQuery = session.createSQLQuery(countsql);
			if (parameterMap != null) {
				sqlQuery.setProperties(parameterMap);
			}
			FwkLogHelper.LOGGER.debug(countsql);
			Number count = (Number) sqlQuery.uniqueResult();
			if (count != null) {
				rowCount = count.intValue();
			}
		} else {
			
			// 使用HQL进行总记录数查询
			String counthql = queryHql;
			int index = queryHql.toLowerCase().indexOf("from");
			if (index == -1) {
				throw new AppException("分页处理：queryHql必须包含from关键字");
			} else if (index > 0) {
				counthql = counthql.substring(index);
			}
			counthql = "select count(*) as count " + counthql;
			Query query = session.createQuery(counthql);
			if (parameterMap != null) {
				query.setProperties(parameterMap);
			}
			FwkLogHelper.LOGGER.debug(counthql);
			Number count = (Number) query.uniqueResult();
			if (count != null) {
				rowCount = count.intValue();
			}
		}

		// 每页记录数
		int pageSize = pageInfo.getPageSize();

		// 页面总数
		int pageCount = 0;

		// 当前页码
		int pageNum = pageInfo.getPageNum();
		
		// 偏移量
		int offset = 0;
		
		if (pageSize <= 0) {
			throw new AppException("分页查询：每页记录数没有找到。");
		}

		if (pageNum < 1) {
			pageNum = 1;
		}

		if (rowCount % pageSize == 0) {

			if (rowCount == 0) {
				pageCount = 1;
			} else {
				pageCount = rowCount / pageSize;
			}

		} else {
			pageCount = rowCount / pageSize + 1;
		}

		if (pageNum > pageCount) {
			pageNum = pageCount;
		}

		if (rowCount > 0) {
			offset = (pageNum - 1) * pageSize;
		}

		// 设置分页信息
		pageInfo.setPageSize(pageSize);
		pageInfo.setPageCount(pageCount);
		pageInfo.setRowCount(rowCount);
		pageInfo.setPageNum(pageNum);
		
		// 结果LIST
		List resutList = null;
		
		// 进行查询操作
		if (querySql != null) {
			SQLQuery sqlQuery = session.createSQLQuery(querySql);
			if (parameterMap != null) {
				sqlQuery.setProperties(parameterMap);
			}
			sqlQuery.setFirstResult(offset);
			sqlQuery.setMaxResults(pageSize);
			FwkLogHelper.LOGGER.debug(querySql);
			resutList = sqlQuery.list();
		} else {
			Query query = session.createQuery(queryHql);
			if (parameterMap != null) {
				query.setProperties(parameterMap);
			}
			query.setFirstResult(offset);
			query.setMaxResults(pageSize);
			FwkLogHelper.LOGGER.debug(queryHql);
			resutList = query.list();
		}

		FwkLogHelper.LOGGER.debug(pageInfo.getPageSize() + " size, " + pageInfo.getRowCount() + " records, " + pageInfo.getPageNum() + " / " + pageInfo.getPageCount());
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return resutList;
	}

}
