package com.isoftstone.fwk.page;

/**
 * 分页信息
 * @author jitao
 */
public class PageInfo {
	
	/**
	 * 每页记录数
	 */
	private int pageSize = 0;
	
	/**
	 * 总页数
	 */
	private int pageCount = 1;
	
	/**
	 * 当前页码
	 */
	private int pageNum = 1;
	
	/**
	 * 总记录数
	 */
	private int rowCount = 0;
	
	/**
	 * 构造方法
	 * @param pageSize 每页记录数
	 */
	public PageInfo(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * 取得每页记录数
	 * @return 每页记录数
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * 设置每页记录数
	 * @param pageSize 每页记录数
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * 取得总页数
	 * @return 总页数
	 */
	public int getPageCount() {
		return pageCount;
	}

	/**
	 * 设置总页数
	 * @param pageCount 总页数
	 */
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	/**
	 * 取得当前页码
	 * @return 当前页码
	 */
	public int getPageNum() {
		return pageNum;
	}

	/**
	 * 设置当前页码
	 * @param pageNum 当前页码
	 */
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	/**
	 * 取得总记录数
	 * @return 总记录数
	 */
	public int getRowCount() {
		return rowCount;
	}

	/**
	 * 设置总记录数
	 * @param rowCount 总记录数
	 */
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

}
