package com.isoftstone.fwk.param;

/**
 * 拥有权限用户应实现的接口
 * @author jitao
 */
public interface PermissionUser {
	
	/**
	 * 是否拥有指定元素的权限
	 * @param ele 权限元素
	 * @return true:拥有, false:无权
	 */
	boolean containsGrtEle(String ele);
	
	/**
	 * 是否拥有指定角色的权限
	 * @param role 权限角色
	 * @return true:拥有, false:无权
	 */
	boolean containsGrtRole(String role);
	
	/**
	 * 是否是超级管理员
	 * @return true:是, false:否
	 */
	boolean isSuperAdmin();

}
