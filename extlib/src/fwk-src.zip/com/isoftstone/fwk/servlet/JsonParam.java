package com.isoftstone.fwk.servlet;

import com.isoftstone.fwk.helper.BeanHelper;


/**
 * 用户输出json用的参数
 * @author jitao
 */
public class JsonParam {
	
	/**
	 * 回应标志
	 */
	private String respFlg;
	
	/**
	 * 回应消息
	 */
	private Object message;
	
	/**
	 * 回应数据
	 */
	private Object data;
	
	/**
	 * 自定义数据
	 */
	private Object cusData;
	
	/**
	 * 构造方法
	 * @param respFlg 回应标志
	 */
	public JsonParam(String respFlg) {
		this.respFlg = respFlg;
	}

	/**
	 * 取得回应标志
	 * @return 回应标志
	 */
	public String getRespFlg() {
		return respFlg;
	}

	/**
	 * 设置回应标志
	 * @param respFlg 回应标志
	 */
	public void setRespFlg(String respFlg) {
		this.respFlg = respFlg;
	}

	/**
	 * 取得回应数据
	 * @return 回应数据
	 */
	public Object getData() {
		return data;
	}

	/**
	 * 设置回应数据
	 * @param data 回应数据
	 */
	public void setData(Object data) {
		this.data = data;
	}

	/**
	 * 取得自定义数据
	 * @return 自定义数据
	 */
	public Object getCusData() {
		return cusData;
	}

	/**
	 * 设置自定义数据
	 * @param cusData 自定义数据
	 */
	public void setCusData(Object cusData) {
		this.cusData = cusData;
	}
	
	/**
	 * 对象输出字符串
	 * @return 字符串
	 */
	public String toString() {
		return BeanHelper.toString(this);
	}

	/**
	 * 取得回应消息
	 * @return 回应消息
	 */
	public Object getMessage() {
		return message;
	}

	/**
	 * 设置回应消息
	 * @param message 回应消息
	 */
	public void setMessage(Object message) {
		this.message = message;
	}

}
