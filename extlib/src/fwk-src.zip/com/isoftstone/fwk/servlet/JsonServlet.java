package com.isoftstone.fwk.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.isoftstone.fwk.constant.FwkConstant;
import com.isoftstone.fwk.gson.GsonDateTypeAdapter;
import com.isoftstone.fwk.gson.GsonNumberTypeAdapter;
import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * 生成JSON数据的Servelt
 * @author jitao
 */
public class JsonServlet extends HttpServlet {

	/**
	 * doGet
	 * @param req HttpServletRequest
	 * @param resp HttpServletResponse
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * doPost
	 * @param req HttpServletRequest
	 * @param resp HttpServletResponse
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 取得Json
		Object json = req.getAttribute(FwkConstant.JSON_PARAM);
		
		// 如果不存在Json则输出错误的Json表达
		if (json == null) {
			JsonParam jsonParam = new JsonParam(FwkConstant.RESP_FLG_ERR);
			jsonParam.setMessage("JsonServlet无法获得JSON表达对象。");
			jsonParam.setData("JsonServlet.doPost.");
			json = jsonParam;
		}
		
		// 生成GsonBuilder
		GsonBuilder builder = new GsonBuilder();
		
		// 注册Gson对象的类型代理器
		builder.registerTypeAdapter(Date.class, new GsonDateTypeAdapter());
		builder.registerTypeAdapter(java.sql.Date.class, new GsonDateTypeAdapter());
		builder.registerTypeAdapter(java.sql.Time.class, new GsonDateTypeAdapter());
		builder.registerTypeAdapter(java.sql.Timestamp.class, new GsonDateTypeAdapter());
		builder.registerTypeAdapter(Double.class, new GsonNumberTypeAdapter());
		builder.registerTypeAdapter(Float.class, new GsonNumberTypeAdapter());
		builder.registerTypeAdapter(Long.class, new GsonNumberTypeAdapter());
		builder.registerTypeAdapter(Integer.class, new GsonNumberTypeAdapter());
		builder.registerTypeAdapter(BigDecimal.class, new GsonNumberTypeAdapter());
		
		// 输出null值对象
		builder.serializeNulls();
		
		// 生成Gson
		Gson gson = builder.create();
		
		// 设置响应头信息
		resp.setContentType("text/plain; charset=UTF-8");
		
		// 输出JSON字符串
		String jsonStr = gson.toJson(json);
		FwkLogHelper.LOGGER.debug("服务器响应JSON内容：" + jsonStr);
		resp.getWriter().write(jsonStr);
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

}
