package com.isoftstone.fwk.struts1;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.RequestProcessor;

import com.isoftstone.fwk.annotation.GrtEle;
import com.isoftstone.fwk.annotation.GrtRole;
import com.isoftstone.fwk.constant.FwkConstant;
import com.isoftstone.fwk.exception.AppException;
import com.isoftstone.fwk.exception.CheckException;
import com.isoftstone.fwk.filter.LoginUserHolder;
import com.isoftstone.fwk.filter.SessionHolder;
import com.isoftstone.fwk.helper.ActionHelper;
import com.isoftstone.fwk.helper.FwkLogHelper;
import com.isoftstone.fwk.param.PermissionUser;
import com.isoftstone.fwk.servlet.JsonParam;

/**
 * 扩展Struts1中的RequestProcessor
 * @author jitao
 */
public class FwkProcessor extends RequestProcessor {
	
	/**
	 * 校验权限控制
	 * @param action Action
	 * @param form ActionForm
	 * @return true:未通过校验 false:通过校验，正常
	 * @throws AppException 当出现权限校验异常时出现
	 */
	protected void checkPermission(Action action, ActionForm form) throws AppException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 未登录或登录用户对象没有实现权限接口则无需校验，返回正常
		Object loginUser = LoginUserHolder.getUser();
		if (loginUser == null || !(loginUser instanceof PermissionUser)) {
			
			FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
			return;
		}
		
		GrtEle grtEle = null;
		GrtRole grtRole = null;
		if (form != null) {
			grtEle = form.getClass().getAnnotation(GrtEle.class);
			grtRole = form.getClass().getAnnotation(GrtRole.class);
		}
		if (grtEle == null && grtRole == null && action != null) {
			grtEle = action.getClass().getAnnotation(GrtEle.class);
			grtRole = action.getClass().getAnnotation(GrtRole.class);
		}
		if (grtEle != null || grtRole != null) {
			boolean check = true;
			PermissionUser user = (PermissionUser) loginUser;
			if (user.isSuperAdmin()) {
				
				// 超级管理员可执行
				check = false;
			}
			if (check && grtRole != null) {
				String[] roles = grtRole.value();
				for (int i = 0; i < roles.length; i++) {
					String rolestr = roles[i].trim();
					if (rolestr.length() > 0 && user.containsGrtRole(rolestr)) {
						
						// 拥有指定权限角色之一
						check = false;
					}
				}
			}
			if (check && grtEle != null) {
				String[] eles = grtEle.value();
				for (int i = 0; i < eles.length; i++) {
					String elestr = eles[i].trim();
					if (elestr.length() > 0 && user.containsGrtEle(elestr)) {
						
						// 拥有指定权限元素之一
						check = false;
					}
				}
			}
			if (check) {
				throw new AppException("You do not have permission to access this page!");
			}
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 对URL的GET参数进行分析，对已编码的URL参数进行解码，并重新填充到ActionForm中。
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @param form ActionForm
	 * @param mapping ActionMapping
	 */
	protected void processUrlparameter(HttpServletRequest request, HttpServletResponse response, ActionForm form, ActionMapping mapping) throws ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		if (form == null) {
			FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
			return;
		}
		
		String paramStr = request.getQueryString();
		if (paramStr == null || paramStr.equals("") || paramStr.indexOf("%") == -1) {
			FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
			return;
		}
		
		try {
			HashMap<String, ArrayList<String>> parameter = new HashMap<String, ArrayList<String>>();
			
			// 将参数字符串解析成为结构对象
			String[] paramArr = paramStr.split("&+");
			String[] arr = null;
			for (int i = 0; i < paramArr.length; i++) {
				arr = paramArr[i].split("=", 2);
				ArrayList<String> lst = parameter.get(arr[0]);
				if (lst == null) {
					lst = new ArrayList<String>();
					parameter.put(arr[0], lst);
				}
				if (arr.length < 2) {
					lst.add("");
				} else {
					lst.add(arr[1]);
				}
			}
			
			// 循环遍历，如果参数值中存在需要解码的，将对form的属性重新赋值，如果无需解码的将忽略。
			Iterator<String> keyIter = parameter.keySet().iterator();
			
			String[] valueArr = null;
			String key = "";
			while (keyIter.hasNext()) {
				key = keyIter.next();
				ArrayList<String> lst = parameter.get(key);
				valueArr = new String[lst.size()];
				boolean hasUrlCode = false;
				for (int i = 0; i < lst.size(); i++) {
					String value = lst.get(i);
					if (value != null && value.contains("%")) {
						valueArr[i] = URLDecoder.decode(value, "UTF-8");
						hasUrlCode = true;
					} else {
						valueArr[i] = value;
					}
				}
				if (hasUrlCode) {
					FwkLogHelper.LOGGER.info("URL参数解码" + key + "=" + Arrays.toString(valueArr));
					BeanUtils.setProperty(form, key, valueArr);
				}
			}
			
		} catch (UnsupportedEncodingException e) {
			FwkLogHelper.LOGGER.warn("UTF-8 was unsupported");
		} catch (Exception e) {
			throw new ServletException(e);
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 重写Struts的processPopulate方法。<br>
	 * ① 增加对URL中GET参数的中文支持<br>
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @param form ActionForm
	 * @param mapping ActionMapping
	 */
	protected void processPopulate(HttpServletRequest request, HttpServletResponse response, ActionForm form, ActionMapping mapping) throws ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());

		String populateFlg = (String) request.getAttribute("populateFlg");
		if (populateFlg == null) {
			super.processPopulate(request, response, form, mapping);
			processUrlparameter(request, response, form, mapping);
			FwkLogHelper.LOGGER.debug("execute RequestProcessor::processPopulate().");
			request.setAttribute("populateFlg", "1");
		}

		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}
	
	/**
	 * 重写Struts的processActionPerform方法。<br>
	 * ①对来自ajax的请求，将返回json数据页面<br>
	 * ②发生校验错误时，封装错误JsonParam数据，返回Json数据页面<br>
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @param action Action
	 * @param form ActionForm
	 * @param mapping ActionMapping
	 * @return ActionForward
	 */
	protected ActionForward processActionPerform(
			HttpServletRequest request,
			HttpServletResponse response,
			Action action,
			ActionForm form,
			ActionMapping mapping) throws IOException, ServletException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		ActionForward forward = null;
		
		try {
			
			// 校验权限控制
			checkPermission(action, form);
			
			if (FwkLogHelper.LOGGER.isDebugEnabled()) {
				FwkLogHelper.LOGGER.debug("ActionForm输入值：" + form);
			}
			
			// 执行action
			forward = (action.execute(mapping, form, request, response));
			
			if (FwkLogHelper.LOGGER.isDebugEnabled()) {
				FwkLogHelper.LOGGER.debug("ActionForm输出值：" + form);
			}
			
			// 如果请求来自ajax，将封装json数据，并导向json数据输出页面。
			if (ActionHelper.isAjaxFlg(request)) {
				
				// 生成JsonParam对象
				JsonParam jsonParam = new JsonParam(FwkConstant.RESP_FLG_NORMAL); // 回应状态：正常
				jsonParam.setData(ActionHelper.getResponseData(request));         // data数据块
				jsonParam.setCusData(ActionHelper.getResponseCusData(request));   // cusData数据块
				jsonParam.setMessage(ActionHelper.getResponseMessageList(request));   // message数据块
				
				// JsonParam对象封转到request域中
				request.setAttribute(FwkConstant.JSON_PARAM, jsonParam);
				
				// 内部导向
				forward = new ActionForward(FwkConstant.FORWARD_JSON_PATH);
			}
		} catch (CheckException ce) {
			
			// 如果请求来自ajax，封装警告json数据，并导向json数据输出页面
			if (ActionHelper.isAjaxFlg(request)) {
				
				// 生成JsonParam对象(data数据块将失效)
				JsonParam jsonParam = new JsonParam(FwkConstant.RESP_FLG_WARN); // 回应状态：警告
				jsonParam.setCusData(ActionHelper.getResponseCusData(request)); // cusData数据块
				jsonParam.setMessage(ce.getCheckMessageList());                 // 错误信息列表
				
				// JsonParam对象封转到request域中
				request.setAttribute(FwkConstant.JSON_PARAM, jsonParam);
				
				// 发生校验异常，应该使当前线程中的事务回滚
				SessionHolder.markIsRollback(true);
				
				// 内部导向
				forward = new ActionForward(FwkConstant.FORWARD_JSON_PATH);
			} else {
				
				// web页面请求进行默认行为
				forward = (processException(request, response, ce, form, mapping));
			}
		} catch (Exception e) {
			forward = (processException(request, response, e, form, mapping));
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return forward;
	}

	/**
	 * 重写processException方法。<br>
	 * 为了能够使得出现错误时能够抛出到架构层filter进行相关的操作。再次取消struts的ExceptionHandler功能。
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @param exception 异常对象
	 * @param form ActionForm
	 * @param mapping ActionMapping
	 * @return ActionForward
	 */
	protected ActionForward processException(
			HttpServletRequest request,
			HttpServletResponse response,
			Exception exception,
			ActionForm form,
			ActionMapping mapping) throws IOException, ServletException {

        if (exception instanceof IOException) {
            throw (IOException) exception;
        } else if (exception instanceof ServletException) {
            throw (ServletException) exception;
        } else if (exception instanceof RuntimeException) {
            throw (RuntimeException) exception;
        } else {
            throw new AppException(exception);
        }
    }
}
