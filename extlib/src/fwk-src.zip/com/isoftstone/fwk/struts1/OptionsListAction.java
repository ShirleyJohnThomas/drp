package com.isoftstone.fwk.struts1;

import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.isoftstone.fwk.constant.FwkConstant;
import com.isoftstone.fwk.helper.ActionHelper;
import com.isoftstone.fwk.helper.FwkLogHelper;
import com.isoftstone.fwk.tag.OptionsArguments;

/**
 * 获得下拉列表选项FORM
 * @author jitao
 */
public class OptionsListAction extends DispatchAction {
	
	/**
	 * 获得下拉数据
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward getOptions(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		OptionsListForm inForm = (OptionsListForm) form;
		
		// Spring context
		ApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(super.getServlet().getServletContext());
		
		// 封装OptionsArguments
		OptionsArguments args = new OptionsArguments(
				inForm.getArg1(),
				inForm.getArg2(),
				inForm.getArg3(),
				inForm.getArg4(),
				inForm.getArg5(),
				inForm.getArg6(),
				inForm.getArg7(),
				inForm.getArg8());
		
		// 执行操作
		Object bean = context.getBean(inForm.getBeanName());
		Method mtd = bean.getClass().getMethod(inForm.getMethod(), new Class[]{OptionsArguments.class});
		FwkLogHelper.LOGGER.info("开始调用Options服务，beanName=[" + inForm.getBeanName() + "], method=[" + inForm.getMethod() + "], args=[" + args + "]");
		List list = (List) mtd.invoke(bean, new Object[]{args});
		list.add(0, FwkConstant.DEFAULT_OPTION);
		
		// 设置回应数据
		ActionHelper.setResponseData(request, list);
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
		return null;
	}

}
