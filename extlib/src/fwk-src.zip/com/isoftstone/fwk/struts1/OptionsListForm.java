package com.isoftstone.fwk.struts1;

import org.apache.struts.action.ActionForm;

import com.isoftstone.fwk.helper.BeanHelper;

/**
 * 获得下拉列表选项FORM
 * @author jitao
 */
public class OptionsListForm extends ActionForm {
	
	/**
	 * class实例名称
	 */
	private String beanName;
	
	/**
	 * 方法名
	 */
	private String method;
	
	/**
	 * 参数1
	 */
	private String arg1;
	
	/**
	 * 参数2
	 */
	private String arg2;
	
	/**
	 * 参数3
	 */
	private String arg3;
	
	/**
	 * 参数4
	 */
	private String arg4;
	
	/**
	 * 参数5
	 */
	private String arg5;
	
	/**
	 * 参数6
	 */
	private String arg6;
	
	/**
	 * 参数7
	 */
	private String arg7;
	
	/**
	 * 参数8
	 */
	private String arg8;
	
	/**
	 * 取得class实例名称
	 * @return class实例名称
	 */
	public String getBeanName() {
		return beanName;
	}

	/**
	 * 设置class实例名称
	 * @param beanName class实例名称
	 */
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}

	/**
	 * 取得方法名
	 * @return 方法名
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * 设置方法名
	 * @param method 方法名
	 */
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * 取得参数1
	 * @return 参数1
	 */
	public String getArg1() {
		return arg1;
	}

	/**
	 * 设置参数1
	 * @param arg1 参数1
	 */
	public void setArg1(String arg1) {
		this.arg1 = arg1;
	}

	/**
	 * 取得参数2
	 * @return 参数2
	 */
	public String getArg2() {
		return arg2;
	}

	/**
	 * 设置参数2
	 * @param arg2 参数2
	 */
	public void setArg2(String arg2) {
		this.arg2 = arg2;
	}

	/**
	 * 取得参数3
	 * @return 参数3
	 */
	public String getArg3() {
		return arg3;
	}

	/**
	 * 设置参数3
	 * @param arg3 参数3
	 */
	public void setArg3(String arg3) {
		this.arg3 = arg3;
	}

	/**
	 * 取得参数4
	 * @return 参数4
	 */
	public String getArg4() {
		return arg4;
	}

	/**
	 * 设置参数4
	 * @param arg4 参数4
	 */
	public void setArg4(String arg4) {
		this.arg4 = arg4;
	}

	/**
	 * 取得参数5
	 * @return 参数5
	 */
	public String getArg5() {
		return arg5;
	}

	/**
	 * 设置参数5
	 * @param arg5 参数5
	 */
	public void setArg5(String arg5) {
		this.arg5 = arg5;
	}

	/**
	 * 取得参数6
	 * @return 参数6
	 */
	public String getArg6() {
		return arg6;
	}

	/**
	 * 设置参数6
	 * @param arg6 参数6
	 */
	public void setArg6(String arg6) {
		this.arg6 = arg6;
	}

	/**
	 * 取得参数7
	 * @return 参数7
	 */
	public String getArg7() {
		return arg7;
	}

	/**
	 * 设置参数7
	 * @param arg7 参数7
	 */
	public void setArg7(String arg7) {
		this.arg7 = arg7;
	}

	/**
	 * 取得参数8
	 * @return 参数8
	 */
	public String getArg8() {
		return arg8;
	}

	/**
	 * 设置参数8
	 * @param arg8 参数8
	 */
	public void setArg8(String arg8) {
		this.arg8 = arg8;
	}
	
	/**
	 * toString
	 */
	public String toString() {
		return BeanHelper.toString(this);
	}

}
