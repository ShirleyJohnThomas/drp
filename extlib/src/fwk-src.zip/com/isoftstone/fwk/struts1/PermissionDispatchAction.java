package com.isoftstone.fwk.struts1;

import java.lang.reflect.Method;

import org.apache.struts.actions.DispatchAction;

import com.isoftstone.fwk.annotation.GrtEle;
import com.isoftstone.fwk.annotation.GrtRole;
import com.isoftstone.fwk.exception.AppException;
import com.isoftstone.fwk.filter.LoginUserHolder;
import com.isoftstone.fwk.helper.FwkLogHelper;
import com.isoftstone.fwk.param.PermissionUser;

/**
 * 可以校验方法权限的DispatchAction
 * @author jitao
 */
public class PermissionDispatchAction extends DispatchAction {
	
	/**
	 * 校验权限
	 * @param mtd 方法反射对象
	 * @throws AppException 当出现权限校验异常时出现
	 */
	protected void checkPermission(Method mtd) throws AppException {
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodStartMessage());
		
		// 未登录或登录用户对象没有实现权限接口则无需校验，返回正常
		Object loginUser = LoginUserHolder.getUser();
		if (loginUser == null || !(loginUser instanceof PermissionUser)) {
			
			FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
			return;
		}
		
		GrtEle grtEle = mtd.getAnnotation(GrtEle.class);
		GrtRole grtRole = mtd.getAnnotation(GrtRole.class);
		if (grtEle != null || grtRole != null) {
			boolean check = true;
			PermissionUser user = (PermissionUser) loginUser;
			if (user.isSuperAdmin()) {
				
				// 超级管理员可执行
				check = false;
			}
			if (check && grtRole != null) {
				String[] roles = grtRole.value();
				for (int i = 0; i < roles.length; i++) {
					String rolestr = roles[i].trim();
					if (rolestr.length() > 0 && user.containsGrtRole(rolestr)) {
						
						// 拥有指定权限角色之一
						check = false;
					}
				}
			}
			if (check && grtEle != null) {
				String[] eles = grtEle.value();
				for (int i = 0; i < eles.length; i++) {
					String elestr = eles[i].trim();
					if (elestr.length() > 0 && user.containsGrtEle(elestr)) {
						
						// 拥有指定权限元素之一
						check = false;
					}
				}
			}
			if (check) {
				throw new AppException("You do not have permission to access this page!");
			}
		}
		
		FwkLogHelper.LOGGER.debug(FwkLogHelper.getMethodEndMessage());
	}

	protected Method getMethod(String name) throws NoSuchMethodException {
		Method mtd = super.getMethod(name);
		checkPermission(mtd);
		return mtd;
	}
	
}
