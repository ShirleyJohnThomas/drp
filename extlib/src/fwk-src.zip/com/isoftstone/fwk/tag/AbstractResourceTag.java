package com.isoftstone.fwk.tag;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.struts.taglib.TagUtils;

import com.isoftstone.fwk.exception.AppException;
import com.isoftstone.fwk.helper.BasePathHelper;

/**
 * 用来引用如script、CSS资源的标签的父类
 * @author jitao
 */
public abstract class AbstractResourceTag extends TagSupport {
	
	/**
	 * url
	 */
	protected String url;
	
	/**
	 * 是否添加version参数
	 */
	protected boolean version = true;
	
	/**
	 * 字符集编码
	 */
	protected String charset;
	
	/**
	 * 生成HTML代码
	 * @param refUrl 引用地址
	 * @return HTML代码
	 */
	protected abstract String renderHtml(String refUrl);
	
	/**
	 * 生成带有version参数的地址
	 * @param refUrl 引用地址
	 * @return version参数的地址
	 */
	protected String renderVersionParameter(String refUrl) {
		
		// 生成版本参数
		String filePath = url;
		if (filePath.indexOf("?") > -1) {
			filePath = filePath.substring(0, filePath.indexOf("?"));
		}
		if (filePath.indexOf("#") > -1) {
			filePath = filePath.substring(0, filePath.indexOf("#"));
		}
		File scriptFile = new File(BasePathHelper.getBasePath(), filePath);
		if (scriptFile.exists()) {
			try {
				String v = Long.toHexString(scriptFile.lastModified());
				if (refUrl.contains("?")) {
					refUrl = refUrl + "&v=" + v;
				} else {
					refUrl = refUrl + "?v=" + v;
				}
			} catch (Exception e) {
				// do thing.
			}
		}
		
		return refUrl;
	}
	
	/**
	 * 开始标签
	 */
	public int doStartTag() throws JspException {
		return SKIP_BODY;
	}
	
	/**
	 * 结束标签
	 */
	public int doEndTag() throws JspException {
		if (url != null && url.length() > 0) {
			
			// 只支持以'/'开头的地址
			if (!url.startsWith("/")) {
				throw new AppException("script must start with '/' charactor.");
			}
			
			// 生成script地址
			HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
			String refUrl = request.getContextPath() + url;
			if (version) {
				refUrl = renderVersionParameter(refUrl);
			}
			
			// 输出html代码
			String html = renderHtml(refUrl);
			TagUtils.getInstance().write(pageContext, html);
		}
		return EVAL_PAGE;
	}

	/**
	 * 取得url
	 * @return url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * 设置url
	 * @param url url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * 取得是否添加version参数
	 * @return 是否添加version参数
	 */
	public boolean isVersion() {
		return version;
	}

	/**
	 * 设置是否添加version参数
	 * @param version 是否添加version参数
	 */
	public void setVersion(boolean version) {
		this.version = version;
	}

	/**
	 * 取得字符集编码
	 * @return 字符集编码
	 */
	public String getCharset() {
		return charset;
	}

	/**
	 * 设置字符集编码
	 * @param charset 字符集编码
	 */
	public void setCharset(String charset) {
		this.charset = charset;
	}
}
