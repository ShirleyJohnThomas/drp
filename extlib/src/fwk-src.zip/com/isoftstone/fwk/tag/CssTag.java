package com.isoftstone.fwk.tag;

/**
 * 引用css代码的资源
 * @author jitao
 */
public class CssTag extends AbstractResourceTag {

	/**
	 * 生成HTML代码
	 * @param refUrl
	 * @return HTML代码
	 */
	protected String renderHtml(String refUrl) {
		StringBuilder code = new StringBuilder();
		code.append("<link href=\"");
		code.append(refUrl);
		code.append("\" rel=\"stylesheet\" type=\"text/css\"");
		if (super.charset != null && super.charset.length() > 0) {
			code.append(" charset=\"");
			code.append(super.charset);
			code.append("\"");
		}
		code.append(">");
		return code.toString();
	}

}
