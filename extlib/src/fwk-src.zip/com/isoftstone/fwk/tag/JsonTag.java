package com.isoftstone.fwk.tag;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.struts.taglib.TagUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.isoftstone.fwk.gson.GsonDateTypeAdapter;
import com.isoftstone.fwk.gson.GsonNumberTypeAdapter;
import com.isoftstone.fwk.helper.FwkLogHelper;

/**
 * JSON表达式输出标签
 * @author jitao
 */
public class JsonTag extends TagSupport {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * class实例名称
	 */
	private String beanName;
	
	/**
	 * 方法名
	 */
	private String method;
	
	/**
	 * bean名称
	 */
	private String name;
	
	/**
	 * bean属性
	 */
	private String property;
	
	/**
	 * 作用域
	 */
	private String scope;
	
	/**
	 * Bean实例
	 */
	private Object bean;
	
	/**
	 * 是否输出NULL
	 */
	private boolean serializeNull = false;
	
	/**
	 * 参数1
	 */
	private String arg1;
	
	/**
	 * 参数2
	 */
	private String arg2;
	
	/**
	 * 参数3
	 */
	private String arg3;
	
	/**
	 * 参数4
	 */
	private String arg4;
	
	/**
	 * 参数5
	 */
	private String arg5;
	
	/**
	 * 参数6
	 */
	private String arg6;
	
	/**
	 * 参数7
	 */
	private String arg7;
	
	/**
	 * 参数8
	 */
	private String arg8;
	
	/**
	 * 开始标签
	 */
	public int doStartTag() throws JspException {
		return SKIP_BODY;
	}
	
	/**
	 * 结束标签
	 */
	public int doEndTag() throws JspException {
		try {
			Object jsonBean = null;
			if (name != null) {
				if (TagUtils.getInstance().lookup(pageContext, name, scope) == null) {
					jsonBean = null;
				} else {
					jsonBean = TagUtils.getInstance().lookup(pageContext, name, property, scope);
				}
			} else if (beanName != null && method != null) {
				
				// Spring context
				ApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(pageContext.getServletContext());
				
				// 封装JsonArguments
				JsonArguments args = new JsonArguments(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
				
				// 执行操作
				Object bean = context.getBean(beanName);
				Method mtd = bean.getClass().getMethod(method, new Class[]{JsonArguments.class});
				FwkLogHelper.LOGGER.info("开始调用Options服务，beanName=[" + beanName + "], method=[" + method + "], args=[" + args + "]");
				jsonBean = mtd.invoke(bean, new Object[]{args});
			} else {
				jsonBean = bean;
			}
			
			// 生成GsonBuilder
			GsonBuilder builder = new GsonBuilder();
			
			// 注册Gson对象的类型代理器
			builder.registerTypeAdapter(Date.class, new GsonDateTypeAdapter());
			builder.registerTypeAdapter(java.sql.Date.class, new GsonDateTypeAdapter());
			builder.registerTypeAdapter(java.sql.Time.class, new GsonDateTypeAdapter());
			builder.registerTypeAdapter(java.sql.Timestamp.class, new GsonDateTypeAdapter());
			builder.registerTypeAdapter(Double.class, new GsonNumberTypeAdapter());
			builder.registerTypeAdapter(Float.class, new GsonNumberTypeAdapter());
			builder.registerTypeAdapter(Long.class, new GsonNumberTypeAdapter());
			builder.registerTypeAdapter(Integer.class, new GsonNumberTypeAdapter());
			builder.registerTypeAdapter(BigDecimal.class, new GsonNumberTypeAdapter());
			
			// 是否序列化null
			if (serializeNull) {
				builder.serializeNulls();
			}
			
			// 生成Gson
			Gson gson = builder.create();
			String json = gson.toJson(jsonBean);
			if (json == null || json.length() == 0) {
				json = "null";
			}
			
			TagUtils.getInstance().write(pageContext, json);
		} catch (RuntimeException re) {
			throw re;
		} catch (Exception e) {
			throw new JspException(e);
		}
		return EVAL_PAGE;
	}
	
	/**
	 * 取得class实例名称
	 * @return class实例名称
	 */
	public String getBeanName() {
		return beanName;
	}

	/**
	 * 设置class实例名称
	 * @param beanName class实例名称
	 */
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}

	/**
	 * 取得方法名
	 * @return 方法名
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * 设置方法名
	 * @param method 方法名
	 */
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * 取得参数1
	 * @return 参数1
	 */
	public String getArg1() {
		return arg1;
	}

	/**
	 * 设置参数1
	 * @param arg1 参数1
	 */
	public void setArg1(String arg1) {
		this.arg1 = arg1;
	}

	/**
	 * 取得参数2
	 * @return 参数2
	 */
	public String getArg2() {
		return arg2;
	}

	/**
	 * 设置参数2
	 * @param arg2 参数2
	 */
	public void setArg2(String arg2) {
		this.arg2 = arg2;
	}

	/**
	 * 取得参数3
	 * @return 参数3
	 */
	public String getArg3() {
		return arg3;
	}

	/**
	 * 设置参数3
	 * @param arg3 参数3
	 */
	public void setArg3(String arg3) {
		this.arg3 = arg3;
	}

	/**
	 * 取得参数4
	 * @return 参数4
	 */
	public String getArg4() {
		return arg4;
	}

	/**
	 * 设置参数4
	 * @param arg4 参数4
	 */
	public void setArg4(String arg4) {
		this.arg4 = arg4;
	}

	/**
	 * 取得参数5
	 * @return 参数5
	 */
	public String getArg5() {
		return arg5;
	}

	/**
	 * 设置参数5
	 * @param arg5 参数5
	 */
	public void setArg5(String arg5) {
		this.arg5 = arg5;
	}

	/**
	 * 取得参数6
	 * @return 参数6
	 */
	public String getArg6() {
		return arg6;
	}

	/**
	 * 设置参数6
	 * @param arg6 参数6
	 */
	public void setArg6(String arg6) {
		this.arg6 = arg6;
	}

	/**
	 * 取得参数7
	 * @return 参数7
	 */
	public String getArg7() {
		return arg7;
	}

	/**
	 * 设置参数7
	 * @param arg7 参数7
	 */
	public void setArg7(String arg7) {
		this.arg7 = arg7;
	}

	/**
	 * 取得参数8
	 * @return 参数8
	 */
	public String getArg8() {
		return arg8;
	}

	/**
	 * 设置参数8
	 * @param arg8 参数8
	 */
	public void setArg8(String arg8) {
		this.arg8 = arg8;
	}

	/**
	 * 取得Bean实例
	 * @return Bean实例
	 */
	public Object getBean() {
		return bean;
	}

	/**
	 * 设置Bean实例
	 * @param bean Bean实例
	 */
	public void setBean(Object bean) {
		this.bean = bean;
	}

	/**
	 * 取得是否输出NULL
	 * @return 是否输出NULL
	 */
	public boolean isSerializeNull() {
		return serializeNull;
	}

	/**
	 * 设置是否输出NULL
	 * @param serializeNull 是否输出NULL
	 */
	public void setSerializeNull(boolean serializeNull) {
		this.serializeNull = serializeNull;
	}

	/**
	 * 取得bean名称
	 * @return bean名称
	 */
	public String getName() {
		return name;
	}

	/**
	 * 设置bean名称
	 * @param name bean名称
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 取得bean属性
	 * @return bean属性
	 */
	public String getProperty() {
		return property;
	}

	/**
	 * 设置bean属性
	 * @param property bean属性
	 */
	public void setProperty(String property) {
		this.property = property;
	}

	/**
	 * 取得作用域
	 * @return 作用域
	 */
	public String getScope() {
		return scope;
	}

	/**
	 * 设置作用域
	 * @param scope 作用域
	 */
	public void setScope(String scope) {
		this.scope = scope;
	}

}
