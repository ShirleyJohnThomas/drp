package com.isoftstone.fwk.tag;

import com.isoftstone.fwk.helper.BeanHelper;

/**
 * 下拉选项
 * @author jitao
 */
public class Option {
	
	/**
	 * 显示标签
	 */
	private String label;
	
	/**
	 * 值
	 */
	private String value;
	
	/**
	 * 默认构造方法
	 */
	public Option() {
		// do nothing.
	}
	
	/**
	 * 构造方法
	 * @param label 显示标签
	 * @param value 值
	 */
	public Option(String label, String value) {
		this.label = label;
		this.value = value;
	}

	/**
	 * 取得显示标签
	 * @return 显示标签
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * 设置显示标签
	 * @param label 显示标签
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * 取得值
	 * @return 值
	 */
	public String getValue() {
		return value;
	}

	/**
	 * 设置值
	 * @param value 值
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	/**
	 * toString
	 */
	public String toString() {
		return BeanHelper.toString(this);
	}

}
