package com.isoftstone.fwk.tag;

import com.isoftstone.fwk.helper.BeanHelper;

/**
 * 下拉选项取得时需要使用的参数
 * @author jitao
 */
public class OptionsArguments {
	
	/**
	 * 参数1
	 */
	private String arg1;
	
	/**
	 * 参数2
	 */
	private String arg2;
	
	/**
	 * 参数3
	 */
	private String arg3;
	
	/**
	 * 参数4
	 */
	private String arg4;
	
	/**
	 * 参数5
	 */
	private String arg5;
	
	/**
	 * 参数6
	 */
	private String arg6;
	
	/**
	 * 参数7
	 */
	private String arg7;
	
	/**
	 * 参数8
	 */
	private String arg8;
	
	/**
	 * 默认构造方法
	 */
	public OptionsArguments() {
		// do nothing.
	}
	
	/**
	 * 构造方法
	 * @param arg1 参数1
	 * @param arg2 参数2
	 * @param arg3 参数3
	 * @param arg4 参数4
	 * @param arg5 参数5
	 * @param arg6 参数6
	 * @param arg7 参数7
	 * @param arg8 参数8
	 */
	public OptionsArguments(
			String arg1,
			String arg2,
			String arg3,
			String arg4,
			String arg5,
			String arg6,
			String arg7,
			String arg8) {
		this.arg1 = arg1;
		this.arg2 = arg2;
		this.arg3 = arg3;
		this.arg4 = arg4;
		this.arg5 = arg5;
		this.arg6 = arg6;
		this.arg7 = arg7;
		this.arg8 = arg8;
	}
	
	/**
	 * 取得参数1
	 * @return 参数1
	 */
	public String getArg1() {
		return arg1;
	}

	/**
	 * 设置参数1
	 * @param arg1 参数1
	 */
	public void setArg1(String arg1) {
		this.arg1 = arg1;
	}

	/**
	 * 取得参数2
	 * @return 参数2
	 */
	public String getArg2() {
		return arg2;
	}

	/**
	 * 设置参数2
	 * @param arg2 参数2
	 */
	public void setArg2(String arg2) {
		this.arg2 = arg2;
	}

	/**
	 * 取得参数3
	 * @return 参数3
	 */
	public String getArg3() {
		return arg3;
	}

	/**
	 * 设置参数3
	 * @param arg3 参数3
	 */
	public void setArg3(String arg3) {
		this.arg3 = arg3;
	}

	/**
	 * 取得参数4
	 * @return 参数4
	 */
	public String getArg4() {
		return arg4;
	}

	/**
	 * 设置参数4
	 * @param arg4 参数4
	 */
	public void setArg4(String arg4) {
		this.arg4 = arg4;
	}

	/**
	 * 取得参数5
	 * @return 参数5
	 */
	public String getArg5() {
		return arg5;
	}

	/**
	 * 设置参数5
	 * @param arg5 参数5
	 */
	public void setArg5(String arg5) {
		this.arg5 = arg5;
	}

	/**
	 * 取得参数6
	 * @return 参数6
	 */
	public String getArg6() {
		return arg6;
	}

	/**
	 * 设置参数6
	 * @param arg6 参数6
	 */
	public void setArg6(String arg6) {
		this.arg6 = arg6;
	}

	/**
	 * 取得参数7
	 * @return 参数7
	 */
	public String getArg7() {
		return arg7;
	}

	/**
	 * 设置参数7
	 * @param arg7 参数7
	 */
	public void setArg7(String arg7) {
		this.arg7 = arg7;
	}

	/**
	 * 取得参数8
	 * @return 参数8
	 */
	public String getArg8() {
		return arg8;
	}

	/**
	 * 设置参数8
	 * @param arg8 参数8
	 */
	public void setArg8(String arg8) {
		this.arg8 = arg8;
	}
	
	/**
	 * toString
	 */
	public String toString() {
		return BeanHelper.toString(this);
	}
}
