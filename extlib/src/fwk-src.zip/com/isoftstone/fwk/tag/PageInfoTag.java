package com.isoftstone.fwk.tag;

import java.util.Arrays;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.struts.taglib.TagUtils;

import com.isoftstone.fwk.page.PageInfo;

/**
 * 分页信息标签对象
 * @author jitao
 */
public class PageInfoTag extends TagSupport {
	
	/**
	 * pageSize下拉列表选项值数组
	 */
	private static final int[] PAGE_SIZE_ARR = new int[]{10, 20, 50, 100, 200, 500, 999};

	/**
	 * 名称
	 */
	private String name;

	/**
	 * 属性
	 */
	private String property;

	/**
	 * 作用域
	 */
	private String scope;

	/**
	 * 侦听方法
	 */
	private String function;
	
	/**
	 * 分页信息
	 */
	private PageInfo pageInfo;
	
	/**
	 * 生成页面pageSize下拉列表HTML
	 * @param pageInfo 分页信息
	 * @return 下拉列表HTML
	 */
	protected String generatePageSizeSelectHtml(PageInfo pageInfo) {
		int pageSize = pageInfo.getPageSize();
		int[] pageSizeArr = null;
		if (Arrays.binarySearch(PAGE_SIZE_ARR, pageSize) > -1) {
			pageSizeArr = PAGE_SIZE_ARR;
		} else {
			pageSizeArr = new int[PAGE_SIZE_ARR.length + 1];
			for (int i = 0; i < PAGE_SIZE_ARR.length; i++) {
				pageSizeArr[i] = PAGE_SIZE_ARR[i];
			}
			pageSizeArr[pageSizeArr.length - 1] = pageSize;
			Arrays.sort(pageSizeArr);
		}
		StringBuilder selectHtml = new StringBuilder();
		selectHtml.append("<select id=\"");
		selectHtml.append(property);
		selectHtml.append(".pageSizeSel\" onChange=\"pager.go('");
		selectHtml.append(property);
		selectHtml.append("', ");
		selectHtml.append(function);
		selectHtml.append(", 'min');\">");
		for (int i = 0; i < pageSizeArr.length; i++) {
			selectHtml.append("<option value=\"");
			selectHtml.append(pageSizeArr[i]);
			selectHtml.append("\"");
			if (pageSize == pageSizeArr[i]) {
				selectHtml.append(" selected=\"selected\"");
			}
			selectHtml.append(">");
			selectHtml.append(pageSizeArr[i]);
			selectHtml.append("</option>");
		}
		selectHtml.append("</select>");
		return selectHtml.toString();
	}

	/**
	 * 生成分页导航条
	 * @param pageInfo
	 * @return 导航条HTML代码
	 */
	protected String generateNavigator(PageInfo pageInfo) {

		StringBuilder nagigator = new StringBuilder();
		nagigator.append("<div class=\"page_navi\" id=\"");
		nagigator.append(property);
		nagigator.append("\">");
		nagigator.append("<div class=\"icon_page_go\" onclick=\"pager.txtGo('");
		nagigator.append(property);
		nagigator.append("', ");
		nagigator.append(function);
		nagigator.append(");\"></div>");
		nagigator.append("<div class=\"txt_div\">页</div>");
		nagigator.append("<div class=\"slt_div\"><input id=\"");
		nagigator.append(property);
		nagigator.append(".pageInput\" type=\"text\" value=\"");
		nagigator.append(pageInfo.getPageNum());
		nagigator.append("\"></input></div>");
		nagigator.append("<div class=\"txt_div\">跳转到第</div>");
		nagigator.append("<div title=\"尾页\"");
		if (pageInfo.getPageNum() >= pageInfo.getPageCount()) {
			nagigator.append(" class=\"icon_page_last icon_page_disable\"");
			nagigator.append(" disabled=\"disabled\"");
		} else {
			nagigator.append(" class=\"icon_page_last\"");
		}
		nagigator.append(" onclick=\"pager.go('");
		nagigator.append(property);
		nagigator.append("', ");
		nagigator.append(function);
		nagigator.append(", 'max');\"></div>");
		nagigator.append("<div title=\"下一页\"");
		if (pageInfo.getPageNum() >= pageInfo.getPageCount()) {
			nagigator.append(" class=\"icon_page_next icon_page_disable\"");
			nagigator.append(" disabled=\"disabled\"");
		} else {
			nagigator.append(" class=\"icon_page_next\"");
		}
		nagigator.append(" onclick=\"pager.go('");
		nagigator.append(property);
		nagigator.append("', ");
		nagigator.append(function);
		nagigator.append(", 1);\"></div>");
		nagigator.append("<div title=\"上一页\"");
		if (pageInfo.getPageNum() <= 1) {
			nagigator.append(" class=\"icon_page_pre icon_page_disable\"");
			nagigator.append(" disabled=\"disabled\"");
		} else {
			nagigator.append(" class=\"icon_page_pre\"");
		}
		nagigator.append(" onclick=\"pager.go('");
		nagigator.append(property);
		nagigator.append("', ");
		nagigator.append(function);
		nagigator.append(", -1);\"></div>");
		nagigator.append("<div title=\"首页\"");
		if (pageInfo.getPageNum() <= 1) {
			nagigator.append(" class=\"icon_page_home icon_page_disable\"");
			nagigator.append(" disabled=\"disabled\"");
		} else {
			nagigator.append(" class=\"icon_page_home\"");
		}
		nagigator.append(" onclick=\"pager.go('");
		nagigator.append(property);
		nagigator.append("', ");
		nagigator.append(function);
		nagigator.append(", 'min');\"></div>");
		nagigator.append("<div class=\"txt_div\">第<span id=\"");
		nagigator.append(property);
		nagigator.append(".pageNum_span\">");
		nagigator.append(pageInfo.getPageNum());
		nagigator.append("</span>页/共<span id=\"");
		nagigator.append(property);
		nagigator.append(".pageCount_span\">");
		nagigator.append(pageInfo.getPageCount());
		nagigator.append("</span>页,共<span id=\"");
		nagigator.append(property);
		nagigator.append(".rowCount_span\">");
		nagigator.append(pageInfo.getRowCount());
		nagigator.append("</span>条记录,每页最多");
		nagigator.append(generatePageSizeSelectHtml(pageInfo));
		nagigator.append("条记录</div>");
		nagigator.append("<div class=\"clear\"></div>");
		nagigator.append("</div>");

		return nagigator.toString();
	}

	/**
	 * doStartTag
	 * @return int
	 * */
	public int doStartTag() throws JspException {

		return SKIP_BODY;
	}

	/**
	 * doEndTag
	 * @return int
	 * */
	public int doEndTag() throws JspException {
		
		if (name == null && pageInfo == null) {
			String errMsg = "PageInfoTag:name属性与pageInfo属性两者应有一个有值。";
			JspException je = new JspException(errMsg);
			throw je;
		}
		
		Object value = null;
		if (pageInfo != null) {
			value = pageInfo;
		} else {
			value = TagUtils.getInstance().lookup(pageContext, name, property, scope);
		}

		PageInfo pageInfo = null;
		if (!(value instanceof PageInfo)) {
			String errMsg = name + "." + property + "的类型不属于PageInfo类型";
			JspException je = new JspException(errMsg);
			throw je;
		} else {
			pageInfo = (PageInfo)value;
		}

		TagUtils.getInstance().write(pageContext, generateNavigator(pageInfo));

		return EVAL_PAGE;
	}

	/**
	 * release
	 * */
	public void release() {

		name = null;

		property = null;

		scope = null;

		function = null;
		
		pageInfo = null;

		super.release();
	}

	/**
	 * 取得名称
	 * @return 名称
	 */
	public String getName() {
		return name;
	}

	/**
	 * 设置名称
	 * @param name 名称
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 取得属性
	 * @return 属性
	 */
	public String getProperty() {
		return property;
	}

	/**
	 * 设置属性
	 * @param property 属性
	 */
	public void setProperty(String property) {
		this.property = property;
	}

	/**
	 * 取得作用域
	 * @return 作用域
	 */
	public String getScope() {
		return scope;
	}

	/**
	 * 设置作用域
	 * @param scope 作用域
	 */
	public void setScope(String scope) {
		this.scope = scope;
	}

	/**
	 * 取得侦听方法
	 * @return 侦听方法
	 */
	public String getFunction() {
		return function;
	}

	/**
	 * 设置侦听方法
	 * @param function 侦听方法
	 */
	public void setFunction(String function) {
		this.function = function;
	}

	/**
	 * 取得分页信息
	 * @return 分页信息
	 */
	public PageInfo getPageInfo() {
		return pageInfo;
	}

	/**
	 * 设置分页信息
	 * @param pageInfo 分页信息
	 */
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

}

