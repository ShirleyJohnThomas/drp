package com.isoftstone.fwk.tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.struts.taglib.TagUtils;

import com.isoftstone.fwk.filter.LoginUserHolder;
import com.isoftstone.fwk.param.PermissionUser;

/**
 * 权限许可控制标签
 * 判断用户如果拥有指定权限元素或权限角色，才可执行相关操作。
 * NOTE:超级管理员角色固定可以访问。
 * @author jitao
 */
public class PermissionTag extends BodyTagSupport {
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1560003662726318019L;

	/**
	 * 允许的权限元素
	 */
	private String ele;
	
	/**
	 * 允许的权限角色
	 */
	private String role;
	
	/**
	 * 保存BODY部
	 */
	private String saveBody;
	
	/**
	 * 开始标签
	 */
	public int doStartTag() throws JspException {
		PermissionUser user = (PermissionUser) LoginUserHolder.getUser();
		if (user.isSuperAdmin()) {
			
			// 超级管理员可执行
			return EVAL_BODY_BUFFERED;
		}
		if (role != null) {
			String[] roles = role.split(",");
			for (int i = 0; i < roles.length; i++) {
				String rolestr = roles[i].trim();
				if (rolestr.length() > 0 && user.containsGrtRole(rolestr)) {
					
					// 拥有指定权限角色之一
					return EVAL_BODY_BUFFERED;
				}
			}
		}
		if (ele != null) {
			String[] eles = ele.split(",");
			for (int i = 0; i < eles.length; i++) {
				String elestr = eles[i].trim();
				if (elestr.length() > 0 && user.containsGrtEle(elestr)) {
					
					// 拥有指定权限元素之一
					return EVAL_BODY_BUFFERED;
				}
			}
		}
		return SKIP_BODY;
	}
	
	/**
	 * doAfterBody
	 */
	public int doAfterBody() throws JspException {
		
        if (bodyContent != null) {
            String value = bodyContent.getString();
            if (value == null) {
                value = "";
            }
            
            saveBody = value.trim();
        }
        
        return SKIP_BODY;
	}
	
	/**
	 * 结束标签
	 */
	public int doEndTag() throws JspException {
		if (saveBody != null && saveBody.length() > 0) {
			TagUtils.getInstance().write(pageContext, saveBody);
			saveBody = null;
		}
		return EVAL_PAGE;
	}
	
	/**
	 * 释放标签
	 */
	public void release() {
		super.release();
		this.ele = null;
		this.role = null;
		this.saveBody = null;
	}

	/**
	 * 取得允许的权限元素
	 * @return 允许的权限元素
	 */
	public String getEle() {
		return ele;
	}

	/**
	 * 设置允许的权限元素
	 * @param ele 允许的权限元素
	 */
	public void setEle(String ele) {
		this.ele = ele;
	}

	/**
	 * 取得允许的权限角色
	 * @return 允许的权限角色
	 */
	public String getRole() {
		return role;
	}

	/**
	 * 设置允许的权限角色
	 * @param role 允许的权限角色
	 */
	public void setRole(String role) {
		this.role = role;
	}

}
