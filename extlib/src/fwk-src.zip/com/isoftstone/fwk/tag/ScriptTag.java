package com.isoftstone.fwk.tag;

/**
 * 引用script的标签类
 * @author jitao
 */
public class ScriptTag extends AbstractResourceTag {

	/**
	 * 生成HTML代码
	 * @param refUrl
	 * @return HTML代码
	 */
	protected String renderHtml(String refUrl) {
		StringBuilder code = new StringBuilder();
		code.append("<script type=\"text/javascript\" src=\"");
		code.append(refUrl);
		code.append("\"");
		if (super.charset != null && super.charset.length() > 0) {
			code.append(" charset=\"");
			code.append(super.charset);
			code.append("\"");
		}
		code.append("></script>");
		return code.toString();
	}

}
